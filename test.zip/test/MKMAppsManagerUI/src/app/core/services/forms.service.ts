import { Injectable, inject, signal } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { environment } from '../../environments/environment';
import { FormDetailsResponse, FormDetails, FormStatistic, FormTypeEnum, FormStatusResponse, FORM_STATUSES, FORM_TYPES } from '../models/forms.model';
import { GenericResponse } from '../models/shared.model';

@Injectable({
  providedIn: 'root'
})
export class FormsService {
  private http = inject(HttpClient);

  // State
  private _forms = signal<FormDetails[]>([]);
  readonly forms = this._forms.asReadonly();

  public statuses = FORM_STATUSES;
  public formTypes = FORM_TYPES;

  getForms(): Observable<FormDetailsResponse> {
    return this.http.get<FormDetailsResponse>(environment.getAllFormsDetailsEndpoint).pipe(
      tap(response => {
        if (response.data?.formDetails) {
          this._forms.set(response.data.formDetails);
        }
      })
    );
  }

  // API seems to update one form at a time based on the previous code analysis
  updateForm(formDetails: FormDetails): Observable<GenericResponse> {
    return this.http.post<GenericResponse>(environment.updateFormEndpoint, formDetails);
  }

  getFormStatus(formId: string): Observable<FormStatusResponse> {
    let params = new HttpParams().set('formId', formId);
    return this.http.get<FormStatusResponse>(environment.formStatusEndpoint, { params });
  }
}


