import { Injectable, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { environment } from '../../environments/environment';
import { AppsConfigResponse, AppConfig } from '../models/apps.model';
import { GenericResponse } from '../models/shared.model';

@Injectable({
  providedIn: 'root'
})
export class AppsService {
  private http = inject(HttpClient);

  // State for Apps
  private _apps = signal<AppConfig[]>([]);
  readonly apps = this._apps.asReadonly();

  getAppsConfig(): Observable<AppsConfigResponse> {
    return this.http.get<AppsConfigResponse>(environment.appsConfigEndpoint).pipe(
      tap(response => {
        if (response.data?.appsConfigList) {
          this._apps.set(response.data.appsConfigList);
        }
      })
    );
  }

  updateAppsConfig(appsConfigList: AppConfig[]): Observable<GenericResponse> {
    return this.http.post<GenericResponse>(environment.updateAppsConfigEndpoint, appsConfigList).pipe(
      tap(response => {
        if (response.data?.success) {
          // Optimistically update local state or re-fetch
          this._apps.set(appsConfigList);
        }
      })
    );
  }
}


