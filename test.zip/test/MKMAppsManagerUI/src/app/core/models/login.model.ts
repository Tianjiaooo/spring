import { ApiResponse } from './shared.model';

export interface LoginResponse extends ApiResponse {
  data?: {
    userInfo?: UserInfo;
    userToken?: UserToken;
  };
}

export interface UserInfoResponse extends ApiResponse {
  data?: UserInfo;
}

export interface UserInfo {
  email: string;
  userRoles: AdminType[];
}

export interface UserToken {
  token: string;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export enum AdminType {
  ROOT = 'ROOT',
  APPSADMIN = 'APPSADMIN',
  FORMSADMIN = 'FORMSADMIN',
  USERSADMIN = 'USERSADMIN',
  USERSBULKADMIN = 'USERSBULKADMIN'
}


