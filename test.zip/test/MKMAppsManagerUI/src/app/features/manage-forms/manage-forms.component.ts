import { Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormArray, FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { FormsService } from '../../core/services/forms.service';
import { FormDetails, FormTypeEnum, FormStatusEnum, FORM_STATUSES } from '../../core/models/forms.model';
import { forkJoin } from 'rxjs';

@Component({
  selector: 'app-manage-forms',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div class="p-4 bg-white rounded-lg border border-gray-200 shadow-sm">
      <div class="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
        <div>
          <h2 class="text-2xl font-bold text-gray-900">Manage Forms</h2>
          <p class="text-gray-500 mt-1">Configure form availability and schedules.</p>
        </div>
        
        <div class="flex items-center gap-3 w-full md:w-auto">
          <!-- Search Box -->
          <div class="relative w-full md:w-64">
             <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <svg class="w-4 h-4 text-gray-500" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"/>
              </svg>
            </div>
            <input 
              type="text" 
              [formControl]="searchControl"
              class="block w-full p-2 pl-10 text-sm text-gray-900 border border-gray-300 rounded-lg bg-gray-50 focus:ring-blue-500 focus:border-blue-500" 
              placeholder="Search forms..." 
            />
          </div>

           <!-- Update Button -->
           <button 
            (click)="onSubmit()"
            [disabled]="isUpdating() || !hasChanges()"
            class="text-white bg-green-700 hover:bg-green-800 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-2.5 focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2">
            @if (isUpdating()) {
               <svg class="animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
            }
            {{ isUpdating() ? 'Updating...' : 'Update All' }}
             @if (hasChanges()) {
              <span class="inline-flex items-center justify-center w-4 h-4 text-xs font-semibold text-green-800 bg-green-200 rounded-full">!</span>
            }
          </button>
        </div>
      </div>

      <!-- Categories Tabs -->
      <div class="mb-6 border-b border-gray-200">
        <ul class="flex flex-wrap -mb-px text-sm font-medium text-center">
          @for (type of formTypes; track type) {
            <li class="mr-2">
              <button 
                (click)="selectedCategory.set(type)"
                class="inline-block p-4 border-b-2 rounded-t-lg hover:text-gray-600 hover:border-gray-300"
                [ngClass]="selectedCategory() === type ? 'text-blue-600 border-blue-600 active' : 'border-transparent text-gray-500'">
                {{ type }}
              </button>
            </li>
          }
        </ul>
      </div>

       <!-- Loading State -->
       @if (isLoading()) {
        <div class="flex justify-center items-center py-12">
          <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-green-700"></div>
        </div>
      }

       <!-- Forms List -->
       <form [formGroup]="formsForm">
        <div formArrayName="forms" class="space-y-4">
           @for (formGroup of filteredFormsControls(); track getFormId(formGroup)) {
             <div [formGroup]="formGroup" class="bg-gray-50 border border-gray-200 rounded-lg p-4 transition-all hover:shadow-md">
                <div class="flex flex-col md:flex-row justify-between md:items-start gap-4">
                  <!-- Form Header Info -->
                  <div class="flex-grow">
                    <h3 class="text-lg font-bold text-gray-900 mb-1">{{ formGroup.get('formName')?.value }}</h3>
                    <div class="text-xs text-gray-500 mb-2">ID: {{ formGroup.get('formId')?.value }}</div>
                    
                    <!-- Form Rules Array -->
                     <div formArrayName="formConfig">
                        <div formGroupName="0"> <!-- Assuming 1 config for simplicity based on previous structure, but really should iterate -->
                           <div formArrayName="formRules">
                              <div [formGroupName]="0"> <!-- Assuming 1 rule for simplicity -->
                                 <div class="flex items-center gap-3 mb-2">
                                     <span class="text-sm font-medium text-gray-700">Status:</span>
                                     <!-- Status Dropdown -->
                                     <select formControlName="status" class="bg-white border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2">
                                       @for (status of statuses; track status) {
                                         <option [value]="status">{{ status }}</option>
                                       }
                                     </select>
                                     
                                     <!-- Active Toggle -->
                                      <label class="inline-flex items-center cursor-pointer ml-4">
                                        <input type="checkbox" formControlName="active" class="sr-only peer">
                                        <div class="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
                                        <span class="ms-3 text-sm font-medium text-gray-900">Active</span>
                                      </label>
                                 </div>

                                 <!-- Conditional Offline Fields -->
                                 <!-- If Status is Offline Always OR Active is False (logic depends on specific requirement) -->
                                 <!-- Based on previous code: active controls online/offline? Or status? Let's assume Status enum drives logic + Active bool. -->
                                 
                                 <div class="mt-3 grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                      <label class="block mb-1 text-xs font-medium text-gray-500">Display Title</label>
                                      <input type="text" formControlName="displayMessageTitle" class="bg-white border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2">
                                    </div>
                                    <div>
                                      <label class="block mb-1 text-xs font-medium text-gray-500">Display Body</label>
                                      <input type="text" formControlName="displayMessageBody" class="bg-white border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2">
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                </div>
             </div>
           }
           
           @if (filteredFormsControls().length === 0 && !isLoading()) {
              <div class="text-center py-8 text-gray-500">
                No forms found in "{{ selectedCategory() }}" category matching "{{ searchControl.value }}"
              </div>
           }
        </div>
       </form>
    </div>
  `
})
export class ManageFormsComponent {
  private fb = inject(FormBuilder);
  private formsService = inject(FormsService);
  
  // Enums for template
  formTypes = Object.values(FormTypeEnum); // Payment, Amanda, etc.
  statuses = FORM_STATUSES;

  // Signals for UI State
  selectedCategory = signal<FormTypeEnum>(FormTypeEnum.All);
  isLoading = signal(true);
  isUpdating = signal(false);
  hasChanges = signal(false);

  searchControl = this.fb.control('');
  
  formsForm = this.fb.group({
    forms: this.fb.array<FormGroup>([])
  });

  constructor() {
    this.loadForms();
    this.formsForm.valueChanges.subscribe(() => {
        this.hasChanges.set(this.formsForm.dirty);
    });
  }

  get formsArray() {
    return this.formsForm.get('forms') as FormArray;
  }

  filteredFormsControls = computed(() => {
    const category = this.selectedCategory();
    const searchTerm = this.searchControl.value?.toLowerCase() || '';
    const controls = (this.formsArray.controls as FormGroup[]);

    return controls.filter(control => {
      const form = control.value; // Access the form value directly
      // 1. Filter by Category
      // The structure is complex: formConfig -> formType array.
      // We need to check if formConfig[0].formType includes the selected category
      // Or if selected category is 'All'
      
      const formTypes: FormTypeEnum[] = form.formConfig?.[0]?.formType || [];
      const matchesCategory = category === FormTypeEnum.All || formTypes.includes(category);

      if (!matchesCategory) return false;

      // 2. Filter by Search
      const formName = form.formName?.toLowerCase() || '';
      return formName.includes(searchTerm);
    });
  });

  getFormId(control: FormGroup): string {
    return control.get('formId')?.value;
  }

  loadForms() {
    this.isLoading.set(true);
    this.formsService.getForms().subscribe({
      next: (response) => {
        if (response.data?.formDetails) {
          this.populateForm(response.data.formDetails);
        }
        this.isLoading.set(false);
      },
      error: (err) => {
        console.error('Failed to load forms', err);
        this.isLoading.set(false);
      }
    });
  }

  populateForm(forms: FormDetails[]) {
    this.formsArray.clear();
    forms.forEach(form => {
      this.formsArray.push(this.createFormGroup(form));
    });
    this.formsForm.markAsPristine();
    this.hasChanges.set(false);
  }

  createFormGroup(form: FormDetails): FormGroup {
    // Recreating the deep structure: Form -> FormConfig[] -> FormRules[]
    // Based on provided interfaces, config is an OBJECT not array in interface, but code usage suggested array? 
    // Wait, interface FormDetails { formConfig: FormConfig }. FormConfig { formRules: FormRule[] }.
    // Let's stick to the interface I wrote in forms.model.ts
    
    // Note: In the HTML I used formArrayName="formConfig" assuming it was an array based on some ambiguity.
    // Let's check model:
    // export interface FormDetails { formConfig: FormConfig; } -> Single Object.
    // export interface FormConfig { formRules: FormRule[]; } -> Array of Rules.
    
    // Correction for FormGroup structure:
    return this.fb.group({
      formId: [form.formId],
      formName: [form.formName],
      formConfig: this.fb.array([ // Wrap in array to match the HTML structure I wrote (easier to use existing HTML logic or fix HTML)
          // Actually, let's fix the HTML to be correct for an Object if it is one. 
          // But wait, the previous code showed `formConfig?.formType.forEach`.
          // Let's simplify and map it flatly for the UI if possible, or just follow structure.
          
          this.fb.group({
             formType: [form.formConfig.formType],
             formRules: this.fb.array(
                 form.formConfig.formRules.map(rule => this.createRuleGroup(rule))
             )
          })
      ])
    });
  }

  createRuleGroup(rule: any): FormGroup {
    return this.fb.group({
      ruleName: [rule.ruleName],
      status: [rule.status],
      active: [rule.active],
      displayMessageTitle: [rule.displayMessageTitle],
      displayMessageBody: [rule.displayMessageBody],
       // ... other fields
    });
  }

  onSubmit() {
    if (this.formsForm.invalid) return;

    // Collect ONLY dirty forms
    const dirtyControls = (this.formsArray.controls as FormGroup[]).filter(c => c.dirty);
    
    if (dirtyControls.length === 0) return;

    this.isUpdating.set(true);

    // Prepare Observables for batch update
    // The API updates one form at a time: updateForm(formDetails)
    // We need to reconstruct the FormDetails object from the FormGroup
    
    const updateRequests = dirtyControls.map(control => {
       const formVal = control.getRawValue();
       // Unwrap the weird array structure I made above
       const rawConfig = formVal.formConfig[0];
       
       const formDetails: FormDetails = {
           formId: formVal.formId,
           formName: formVal.formName,
           formConfig: {
               formType: rawConfig.formType,
               formRules: rawConfig.formRules
           }
       };
       return this.formsService.updateForm(formDetails);
    });

    forkJoin(updateRequests).subscribe({
      next: (results) => {
         this.isUpdating.set(false);
         // Ideally check all results for success
         alert('Updated ' + results.length + ' forms successfully.');
         this.formsForm.markAsPristine();
         this.hasChanges.set(false);
         // Reload to get fresh state? Or just trust local.
         this.loadForms(); 
      },
      error: (err) => {
        this.isUpdating.set(false);
        alert('Some updates failed.');
        console.error(err);
      }
    });
  }
}
