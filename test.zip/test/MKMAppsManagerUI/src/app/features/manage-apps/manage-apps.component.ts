import { Component, computed, effect, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormArray, FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { AppsService } from '../../core/services/apps.service';
import { AppConfig } from '../../core/models/apps.model';
import { MatSnackBar } from '@angular/material/snack-bar'; // Will need to install/configure Material or use a custom toast
// Since we are using Tailwind, I will implement a custom Toast/Notification system later or use a simple alert for now.
// For now, let's stick to standard Angular + Tailwind.

@Component({
  selector: 'app-manage-apps',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div class="p-4 bg-white rounded-lg border border-gray-200 shadow-sm">
      <div class="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
        <div>
          <h2 class="text-2xl font-bold text-gray-900">Manage Apps</h2>
          <p class="text-gray-500 mt-1">Turn apps on/off and configure offline messages.</p>
        </div>
        
        <div class="flex items-center gap-3 w-full md:w-auto">
          <!-- Search Box -->
          <div class="relative w-full md:w-64">
            <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <svg class="w-4 h-4 text-gray-500" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"/>
              </svg>
            </div>
            <input 
              type="text" 
              [formControl]="searchControl"
              class="block w-full p-2 pl-10 text-sm text-gray-900 border border-gray-300 rounded-lg bg-gray-50 focus:ring-blue-500 focus:border-blue-500" 
              placeholder="Search apps..." 
            />
          </div>

          <!-- Update Button -->
          <button 
            (click)="onSubmit()"
            [disabled]="isUpdating() || !hasChanges()"
            class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2">
            @if (isUpdating()) {
              <svg class="animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
            }
            {{ isUpdating() ? 'Updating...' : 'Update All' }}
            @if (hasChanges()) {
              <span class="inline-flex items-center justify-center w-4 h-4 text-xs font-semibold text-blue-800 bg-blue-200 rounded-full">
                !
              </span>
            }
          </button>
        </div>
      </div>

      <!-- Loading State -->
      @if (isLoading()) {
        <div class="flex justify-center items-center py-12">
          <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-700"></div>
        </div>
      }

      <!-- Error State -->
      @if (errorMessage()) {
        <div class="p-4 mb-4 text-sm text-red-800 rounded-lg bg-red-50" role="alert">
          <span class="font-medium">Error:</span> {{ errorMessage() }}
        </div>
      }

      <!-- Apps List -->
      <form [formGroup]="appsForm" class="space-y-4">
        <div formArrayName="apps">
          @for (appGroup of filteredAppsControls(); track getAppId(appGroup)) {
            <div [formGroup]="appGroup" class="p-4 mb-4 bg-gray-50 border border-gray-200 rounded-lg transition-all hover:shadow-md">
              <div class="flex items-center justify-between">
                <!-- App Name & Status Indicator -->
                <div class="flex items-center gap-3">
                  <div class="w-2.5 h-2.5 rounded-full" 
                    [ngClass]="appGroup.get('online')?.value ? 'bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]' : 'bg-red-500'">
                  </div>
                  <h3 class="text-lg font-semibold text-gray-900 uppercase tracking-wide">
                    {{ appGroup.get('appName')?.value }}
                  </h3>
                  <span 
                    class="px-2.5 py-0.5 rounded text-xs font-medium"
                    [ngClass]="appGroup.get('online')?.value ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'">
                    {{ appGroup.get('online')?.value ? 'ONLINE' : 'OFFLINE' }}
                  </span>
                </div>

                <!-- Toggle Switch -->
                <label class="inline-flex items-center cursor-pointer">
                  <input type="checkbox" formControlName="online" class="sr-only peer">
                  <div class="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                </label>
              </div>

              <!-- Offline Message Configuration (Collapsible) -->
              <div 
                class="grid grid-cols-1 gap-4 mt-4 overflow-hidden transition-all duration-300 ease-in-out"
                [class.max-h-0]="appGroup.get('online')?.value"
                [class.opacity-0]="appGroup.get('online')?.value"
                [class.max-h-96]="!appGroup.get('online')?.value"
                [class.opacity-100]="!appGroup.get('online')?.value"
                formGroupName="displayMessage">
                
                <div class="pt-4 border-t border-gray-200">
                  <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label class="block mb-2 text-sm font-medium text-gray-900">Offline Title</label>
                      <input type="text" formControlName="displayMessageTitle" class="bg-white border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5">
                    </div>
                    <div>
                      <label class="block mb-2 text-sm font-medium text-gray-900">Offline Message</label>
                      <input type="text" formControlName="displayMessageBody" class="bg-white border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5">
                    </div>
                  </div>
                </div>
              </div>
            </div>
          }
          
          @if (filteredAppsControls().length === 0 && !isLoading()) {
            <div class="text-center py-8 text-gray-500">
              No apps found matching "{{ searchControl.value }}"
            </div>
          }
        </div>
      </form>
    </div>
  `
})
export class ManageAppsComponent {
  private fb = inject(FormBuilder);
  private appsService = inject(AppsService);

  appsForm = this.fb.group({
    apps: this.fb.array<FormGroup>([])
  });
  
  searchControl = this.fb.control('');

  isLoading = signal(true);
  isUpdating = signal(false);
  errorMessage = signal('');
  hasChanges = signal(false);

  // Filtered Apps Logic
  appsArray = computed(() => this.appsForm.get('apps') as FormArray);
  filteredAppsControls = computed(() => {
    const searchTerm = this.searchControl.value?.toLowerCase() || '';
    const controls = this.appsArray().controls as FormGroup[];
    
    if (!searchTerm) return controls;

    return controls.filter(control => {
      const appName = control.get('appName')?.value?.toLowerCase() || '';
      return appName.includes(searchTerm);
    });
  });

  constructor() {
    this.loadApps();
    
    // Watch for form changes to enable Update button
    this.appsForm.valueChanges.subscribe(() => {
      this.hasChanges.set(this.appsForm.dirty);
    });
  }

  getAppId(control: FormGroup): string {
    return control.get('appName')?.value || Math.random().toString();
  }

  loadApps() {
    this.isLoading.set(true);
    this.appsService.getAppsConfig().subscribe({
      next: (response) => {
        if (response.data?.appsConfigList) {
          this.populateForm(response.data.appsConfigList);
        }
        this.isLoading.set(false);
      },
      error: (err) => {
        this.errorMessage.set('Failed to load apps configuration.');
        this.isLoading.set(false);
      }
    });
  }

  populateForm(apps: AppConfig[]) {
    const appsArray = this.appsForm.get('apps') as FormArray;
    appsArray.clear();

    apps.forEach(app => {
      appsArray.push(this.createAppGroup(app));
    });
    
    // Reset dirty state after initial load
    this.appsForm.markAsPristine();
    this.hasChanges.set(false);
  }

  createAppGroup(app: AppConfig): FormGroup {
    return this.fb.group({
      appName: [app.appName], // Read-only usually
      online: [app.online],
      offlineStartDateTime: [app.offlineStartDateTime],
      offlineEndDateTime: [app.offlineEndDateTime],
      updateDate: [app.updateDate],
      displayMessage: this.fb.group({
        displayMessageTitle: [app.displayMessage?.displayMessageTitle || ''],
        displayMessageBody: [app.displayMessage?.displayMessageBody || '']
      })
    });
  }

  onSubmit() {
    if (this.appsForm.invalid) return;

    this.isUpdating.set(true);
    const formValue = this.appsForm.getRawValue(); // use getRawValue to include disabled fields if any
    const appsList: AppConfig[] = formValue.apps;

    this.appsService.updateAppsConfig(appsList).subscribe({
      next: (response) => {
        this.isUpdating.set(false);
        if (response.data?.success) {
          // Success Feedback
          this.appsForm.markAsPristine();
          this.hasChanges.set(false);
          alert('Apps configuration updated successfully!'); // Replace with better toast later
        } else {
          this.errorMessage.set(response.data?.message || 'Update failed');
        }
      },
      error: (err) => {
        this.isUpdating.set(false);
        this.errorMessage.set('An error occurred while updating.');
      }
    });
  }
}
