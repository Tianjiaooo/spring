import { Component, computed, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { LoginService } from '../../core/services/login.service';
import { AppsService } from '../../core/services/apps.service';
import { FormsService } from '../../core/services/forms.service';
import { AdminType } from '../../core/models/login.model';
import { AppConfig } from '../../core/models/apps.model';
import { FormDetails } from '../../core/models/forms.model';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <!-- Decorative Background Overlay -->
    <div class="absolute top-0 left-0 right-0 h-64 bg-gradient-to-br from-slate-900 to-slate-800 -z-10"></div>

    <div class="relative z-10 max-w-7xl mx-auto">
      <!-- Hero Section -->
      <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-10 pt-6 text-white">
        <div>
          <h1 class="text-3xl font-bold tracking-tight">
            Dashboard
          </h1>
          <p class="text-slate-300 mt-1 text-lg">
            Welcome back, <span class="font-semibold text-white">{{ firstName() }}</span>. System overview at a glance.
          </p>
        </div>
        <!-- Optional Global Date/Time or Quick Action could go here -->
        <div class="mt-4 md:mt-0 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-lg border border-white/10 text-sm font-medium">
          {{ currentDate | date:'fullDate' }}
        </div>
      </div>

      <!-- Main Grid Layout (Adaptive 2-Column Grid for better "Big Card" feel) -->
      <!-- Using grid-cols-2 ensures cards are substantial and wide, not squeezed -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">

        <!-- 1. MANAGE APPS WIDGET -->
        @if (canManageApps()) {
          <div class="group bg-white rounded-2xl p-0 shadow-sm border border-slate-200 hover:shadow-xl hover:border-blue-200 transition-all duration-300 flex flex-col h-full overflow-hidden">
            <!-- Header Bar -->
            <div class="h-1.5 w-full bg-blue-600 group-hover:bg-blue-500 transition-colors"></div>
            
            <div class="p-6 md:p-8 flex flex-col flex-1 relative">
              <!-- Decorative Icon Background -->
              <div class="absolute top-6 right-6 p-3 bg-blue-50 rounded-2xl text-blue-600 group-hover:scale-110 transition-transform duration-300">
                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                   <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"></path>
                </svg>
              </div>

              <div class="mb-6">
                <h3 class="text-xl font-bold text-slate-900 group-hover:text-blue-700 transition-colors">Manage Apps</h3>
                <p class="text-slate-500 text-sm mt-1 w-3/4">Control system-wide application availability.</p>
              </div>

              <!-- Stats / Content Area -->
              <div class="flex-1 mb-8">
                 @if (appsLoading()) {
                   <div class="animate-pulse flex space-x-4">
                     <div class="flex-1 space-y-4 py-1">
                       <div class="h-4 bg-slate-200 rounded w-3/4"></div>
                       <div class="space-y-2">
                         <div class="h-4 bg-slate-200 rounded"></div>
                         <div class="h-4 bg-slate-200 rounded w-5/6"></div>
                       </div>
                     </div>
                   </div>
                 } @else {
                   <div class="flex items-end gap-3 mb-4">
                      <span class="text-5xl font-extrabold text-slate-900 tracking-tight">{{ appsCount() }}</span>
                      <span class="text-sm font-medium text-slate-500 mb-2">Total Applications</span>
                   </div>

                   <!-- Mini List Preview -->
                   <div class="space-y-3 bg-slate-50 rounded-xl p-4 border border-slate-100">
                      @for (app of previewApps(); track app.appName) {
                        <div class="flex items-center justify-between">
                          <span class="text-sm font-medium text-slate-700">{{ app.appName }}</span>
                          <div class="flex items-center gap-2">
                            <span class="relative flex h-2.5 w-2.5">
                              @if(app.online) {
                                <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                                <span class="relative inline-flex rounded-full h-2.5 w-2.5 bg-green-500"></span>
                              } @else {
                                <span class="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500"></span>
                              }
                            </span>
                            <span class="text-xs font-semibold" [ngClass]="app.online ? 'text-green-700' : 'text-red-700'">
                              {{ app.online ? 'Online' : 'Offline' }}
                            </span>
                          </div>
                        </div>
                      }
                      @if (appsCount() > 3) {
                        <div class="text-xs text-center text-slate-400 pt-1 font-medium">View {{ appsCount() - 3 }} more apps</div>
                      }
                   </div>
                 }
              </div>

              <!-- Action Button -->
              <a routerLink="/apps" class="inline-flex justify-center items-center w-full px-5 py-3 text-sm font-semibold text-white bg-slate-900 rounded-xl hover:bg-blue-600 focus:outline-none focus:ring-4 focus:ring-blue-300 transition-all duration-300 shadow-lg shadow-blue-900/10">
                Go to Apps Manager
                <svg class="w-4 h-4 ml-2 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
              </a>
            </div>
          </div>
        }

        <!-- 2. MANAGE FORMS WIDGET -->
        @if (canManageForms()) {
          <div class="group bg-white rounded-2xl p-0 shadow-sm border border-slate-200 hover:shadow-xl hover:border-emerald-200 transition-all duration-300 flex flex-col h-full overflow-hidden">
            <div class="h-1.5 w-full bg-emerald-500 group-hover:bg-emerald-400 transition-colors"></div>
            
            <div class="p-6 md:p-8 flex flex-col flex-1 relative">
               <div class="absolute top-6 right-6 p-3 bg-emerald-50 rounded-2xl text-emerald-600 group-hover:scale-110 transition-transform duration-300">
                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                </svg>
              </div>

              <div class="mb-6">
                <h3 class="text-xl font-bold text-slate-900 group-hover:text-emerald-700 transition-colors">Manage Forms</h3>
                <p class="text-slate-500 text-sm mt-1 w-3/4">Configure form schedules and rules.</p>
              </div>

               <div class="flex-1 mb-8">
                 @if (formsLoading()) {
                   <div class="animate-pulse h-16 bg-slate-100 rounded-xl w-full"></div>
                 } @else {
                   <div class="flex items-end gap-3 mb-6">
                      <span class="text-5xl font-extrabold text-slate-900 tracking-tight">{{ formsCount() }}</span>
                      <span class="text-sm font-medium text-slate-500 mb-2">Total Forms Configured</span>
                   </div>
                   
                   <!-- Stats Grid -->
                   <div class="grid grid-cols-2 gap-4">
                      <div class="p-4 rounded-xl bg-emerald-50/50 border border-emerald-100 flex flex-col items-center justify-center text-center">
                         <span class="text-2xl font-bold text-emerald-700">{{ formsActiveCount() }}</span>
                         <span class="text-xs font-semibold text-emerald-600 uppercase tracking-wide mt-1">Active</span>
                      </div>
                      <div class="p-4 rounded-xl bg-slate-50 border border-slate-100 flex flex-col items-center justify-center text-center">
                         <span class="text-2xl font-bold text-slate-700">{{ formsCount() - formsActiveCount() }}</span>
                         <span class="text-xs font-semibold text-slate-500 uppercase tracking-wide mt-1">Inactive</span>
                      </div>
                   </div>
                 }
               </div>

              <a routerLink="/forms" class="inline-flex justify-center items-center w-full px-5 py-3 text-sm font-semibold text-white bg-slate-900 rounded-xl hover:bg-emerald-600 focus:outline-none focus:ring-4 focus:ring-emerald-300 transition-all duration-300 shadow-lg shadow-emerald-900/10">
                Go to Forms Manager
                <svg class="w-4 h-4 ml-2 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
              </a>
            </div>
          </div>
        }

        <!-- 3. MANAGE USERS WIDGET -->
        @if (canManageUsers()) {
          <div class="group bg-white rounded-2xl p-0 shadow-sm border border-slate-200 hover:shadow-xl hover:border-purple-200 transition-all duration-300 flex flex-col h-full overflow-hidden">
            <div class="h-1.5 w-full bg-purple-600 group-hover:bg-purple-500 transition-colors"></div>
            
            <div class="p-6 md:p-8 flex flex-col flex-1 relative">
               <div class="absolute top-6 right-6 p-3 bg-purple-50 rounded-2xl text-purple-600 group-hover:scale-110 transition-transform duration-300">
                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path>
                </svg>
              </div>

              <div class="mb-6">
                <h3 class="text-xl font-bold text-slate-900 group-hover:text-purple-700 transition-colors">Manage Users</h3>
                <p class="text-slate-500 text-sm mt-1 w-3/4">Handle user roles and verify accounts.</p>
              </div>

              <div class="flex-1 mb-8 flex flex-col justify-center">
                <div class="bg-purple-50 rounded-xl p-5 border border-purple-100 text-center">
                   <div class="text-purple-800 font-semibold mb-1">User Directory</div>
                   <p class="text-sm text-purple-600/80">Manage internal and external user access permissions securely.</p>
                </div>
              </div>

              <a routerLink="/users" class="inline-flex justify-center items-center w-full px-5 py-3 text-sm font-semibold text-white bg-slate-900 rounded-xl hover:bg-purple-600 focus:outline-none focus:ring-4 focus:ring-purple-300 transition-all duration-300 shadow-lg shadow-purple-900/10">
                Go to Users Manager
                <svg class="w-4 h-4 ml-2 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
              </a>
            </div>
          </div>
        }
      </div>
    </div>
  `
})
export class DashboardComponent implements OnInit {
  private loginService = inject(LoginService);
  private appsService = inject(AppsService);
  private formsService = inject(FormsService);

  currentDate = new Date();

  // User Info
  firstName = computed(() => {
    const email = this.loginService.userInfo()?.email || 'User';
    return email.split('@')[0].split('.')[0] || 'User';
  });

  // Permissions
  canManageApps = computed(() => this.loginService.hasRole(AdminType.APPSADMIN));
  canManageForms = computed(() => this.loginService.hasRole(AdminType.FORMSADMIN));
  canManageUsers = computed(() => this.loginService.hasRole(AdminType.USERSADMIN) || this.loginService.hasRole(AdminType.USERSBULKADMIN));

  // Apps Stats
  appsLoading = signal(true);
  appsList = signal<AppConfig[]>([]);
  appsCount = computed(() => this.appsList().length);
  previewApps = computed(() => this.appsList().slice(0, 3));
  appsOfflineCount = computed(() => this.appsList().filter(a => !a.online).length);

  // Forms Stats
  formsLoading = signal(true);
  formsList = signal<FormDetails[]>([]);
  formsCount = computed(() => this.formsList().length);
  formsActiveCount = computed(() => {
    return this.formsList().filter(f => {
       const rule = f.formConfig?.formRules?.[0];
       return rule?.active === true;
    }).length;
  });

  ngOnInit() {
    if (this.canManageApps()) {
      this.appsService.getAppsConfig().subscribe({
        next: (res) => {
          if (res.data?.appsConfigList) this.appsList.set(res.data.appsConfigList);
          this.appsLoading.set(false);
        },
        error: () => this.appsLoading.set(false)
      });
    }

    if (this.canManageForms()) {
      this.formsService.getForms().subscribe({
        next: (res) => {
          if (res.data?.formDetails) this.formsList.set(res.data.formDetails);
          this.formsLoading.set(false);
        },
        error: () => this.formsLoading.set(false)
      });
    }
  }
}
