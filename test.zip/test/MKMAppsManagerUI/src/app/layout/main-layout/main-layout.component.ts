import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { SidebarComponent } from '../sidebar/sidebar.component';
import { HeaderComponent } from '../header/header.component';

@Component({
  selector: 'app-main-layout',
  standalone: true,
  imports: [RouterOutlet, SidebarComponent, HeaderComponent],
  template: `
    <app-header></app-header>
    <app-sidebar></app-sidebar>
    <div class="p-4 sm:ml-64 mt-14 bg-slate-50 min-h-screen">
      <router-outlet></router-outlet>
    </div>
  `
})
export class MainLayoutComponent {}


