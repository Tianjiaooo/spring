import { Routes } from '@angular/router';
import { MainLayoutComponent } from './layout/main-layout/main-layout.component';
import { LoginComponent } from './features/auth/login.component';
import { inject } from '@angular/core';
import { LoginService } from './core/services/login.service';
import { Router } from '@angular/router';

const authGuard = () => {
  const loginService = inject(LoginService);
  const router = inject(Router);
  
  if (loginService.isLoggedIn()) {
    return true;
  }
  return router.createUrlTree(['/login']);
};

export const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: '',
    component: MainLayoutComponent,
    canActivate: [authGuard],
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      { 
        path: 'dashboard', 
        loadComponent: () => import('./features/dashboard/dashboard.component').then(m => m.DashboardComponent) 
      },
      { 
        path: 'apps', 
        loadComponent: () => import('./features/manage-apps/manage-apps.component').then(m => m.ManageAppsComponent) 
      },
      { 
        path: 'forms', 
        loadComponent: () => import('./features/manage-forms/manage-forms.component').then(m => m.ManageFormsComponent) 
      },
      { 
        path: 'users', 
        loadComponent: () => import('./features/manage-users/manage-users.component').then(m => m.ManageUsersComponent) 
      }
    ]
  },
  { path: '**', redirectTo: 'dashboard' }
];
