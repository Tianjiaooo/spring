export const environment = {
  production: false,
  // Placeholders based on context - usually these would come from environment files
  appsConfigEndpoint: '/api/apps/config',
  updateAppsConfigEndpoint: '/api/apps/config/update',
  getAllFormsDetailsEndpoint: '/api/forms/details',
  updateFormEndpoint: '/api/forms/update',
  formStatusEndpoint: '/api/forms/status',
  loginEndpoint: '/api/auth/login',
  userInfoEndpoint: '/api/user/info',
  accessTokenName: 'access_token'
};

