import { Injectable, signal, computed, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { tap, Observable, of, catchError, throwError } from 'rxjs';
import { environment } from '../../environments/environment';
import { LoginRequest, LoginResponse, UserInfo, UserInfoResponse, AdminType } from '../models/login.model';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  private http = inject(HttpClient);
  private router = inject(Router);

  // State using Signals
  private _userInfo = signal<UserInfo | undefined>(undefined);
  private _isLoggedIn = signal<boolean>(false);

  // Read-only signals for components
  readonly userInfo = this._userInfo.asReadonly();
  readonly isLoggedIn = this._isLoggedIn.asReadonly();

  constructor() {
    // Initial check for token
    const token = this.getAccessToken();
    if (token) {
      this._isLoggedIn.set(true);
      // Optionally fetch user info here if not persisted
    }
  }

  login(loginRequest: LoginRequest): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(environment.loginEndpoint, loginRequest).pipe(
      tap(response => {
        if (response.data?.userToken?.token) {
          this.saveAccessToken(response.data.userToken.token);
          this._isLoggedIn.set(true);
        }
        if (response.data?.userInfo) {
          this._userInfo.set(response.data.userInfo);
        }
      })
    );
  }

  logout(): void {
    this.deleteAccessToken();
    this._isLoggedIn.set(false);
    this._userInfo.set(undefined);
    this.router.navigate(['/login']);
  }

  getUserInfo(): Observable<UserInfoResponse> {
    return this.http.get<UserInfoResponse>(environment.userInfoEndpoint).pipe(
      tap(response => {
        if (response.data) {
          this._userInfo.set(response.data);
        }
      })
    );
  }

  hasRole(role: AdminType): boolean {
    const info = this._userInfo();
    if (!info || !info.userRoles) return false;
    return info.userRoles.includes(role) || info.userRoles.includes(AdminType.ROOT);
  }

  // Token Management
  getAccessToken(): string | null {
    return localStorage.getItem(environment.accessTokenName);
  }

  saveAccessToken(token: string): void {
    localStorage.setItem(environment.accessTokenName, token);
  }

  deleteAccessToken(): void {
    localStorage.removeItem(environment.accessTokenName);
  }
}

