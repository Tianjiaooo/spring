import { ApiResponse, DisplayMessage } from './shared.model';

export enum FormTypeEnum {
  Payment = 'Payment',
  Amanda = 'Amanda',
  Tax = 'Tax',
  Standard = 'Standard',
  All = 'All'
}

export enum FormStatusEnum {
  offlineAlways = 'Offline Always',
  offlineBetweenDatesTimes = 'Offline Between Certain Dates and Times'
}

export const FORM_STATUSES: FormStatusEnum[] = [
  FormStatusEnum.offlineAlways,
  FormStatusEnum.offlineBetweenDatesTimes
];

export const FORM_TYPES: FormTypeEnum[] = [
  FormTypeEnum.Payment,
  FormTypeEnum.Amanda,
  FormTypeEnum.Tax,
  FormTypeEnum.Standard
];

export interface FormStatusResponse extends ApiResponse {
  data?: {
    formId?: string;
    formName?: string;
    online?: boolean;
    message?: string;
    displayMessage?: DisplayMessage;
    formType?: FormTypeEnum[];
  };
}

export interface FormDetailsResponse extends ApiResponse {
  data?: {
    formDetails?: FormDetails[];
  };
  success?: boolean;
  message?: string;
}

export interface FormDetails {
  formId: string;
  formName: string;
  formConfig: FormConfig;
}

export interface FormStatistic {
  formType?: FormTypeEnum;
  count?: number;
}

export interface FormConfig {
  formType: FormTypeEnum[];
  formRules: FormRule[];
}

export interface FormRule {
  ruleName?: string;
  status?: FormStatusEnum;
  // Using string for dates/times for simpler JSON handling
  modifiedDate?: string; // moment
  startDate?: string;    // moment
  endDate?: string;      // moment
  startTime?: string;
  endTime?: string;
  active?: boolean;
  displayMessageTitle?: string;
  displayMessageBody?: string;
}

