export interface ApiResponse {
  logId?: string;
  timestamp?: Date;
}

export interface GenericResponse extends ApiResponse {
  data?: {
    success?: boolean;
    message?: string;
  };
}

export interface DisplayMessage {
  displayMessageTitle?: string;
  displayMessageBody?: string;
}

export interface ConfirmDialog {
  title?: string;
  message?: string;
  buttonLabel?: string;
}

export enum ManagerType {
  APPS = 'APPS',
  FORMS = 'FORMS',
  USERS = 'USERS',
  ADMIN_MANAGEMENT = 'ADMIN_MANAGEMENT'
}

