import { ApiResponse } from './shared.model';
import { AdminType } from './login.model';

export interface UsersResponse extends ApiResponse {
  data?: {
    paginationToken?: string | null;
    awsHttpStatusCode?: number;
    awsHttpStatusText?: string;
    users?: User[];
  };
}

export interface BooleanResponse extends ApiResponse {
  data?: {
    result: boolean;
  };
}

export interface UserResponse extends ApiResponse {
  data?: User;
}

export interface User {
  username?: string;
  attributes?: Attribute[];
  enabled?: boolean;
  userStatus?: string;
  userCreateDate?: string;
  userLastModifiedDate?: string;
}

export interface Attribute {
  name: string;
  value: string;
}

export interface UserDisplayType {
  label: string;
  key: string;
  isDate?: boolean;
  isStatus?: boolean;
}

export enum FilterableAttrName {
  USERNAME = 'username',
  EMAIL = 'email',
  EMAIL_VERIFIED = 'email_verified',
  PHONE_NUMBER = 'phone_number',
  PHONE_NUMBER_VERIFIED = 'phone_number_verified',
  NAME = 'name',
  GIVEN_NAME = 'given_name',
  FAMILY_NAME = 'family_name',
  PREFERRED_USERNAME = 'preferred_username'
}

