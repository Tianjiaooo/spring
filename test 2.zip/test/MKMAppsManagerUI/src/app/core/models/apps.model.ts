import { ApiResponse, DisplayMessage } from './shared.model';

export interface AppsConfigResponse extends ApiResponse {
  data?: {
    appsConfigList?: AppConfig[];
  };
}

export interface AppConfig {
  online?: boolean;
  appName?: string;
  // Using string for dates to facilitate serialization/deserialization.
  // Can be converted to Date objects in the UI if needed.
  offlineStartDateTime?: string; // Originally moment.Moment
  offlineEndDateTime?: string;   // Originally moment.Moment
  updateDate?: Date;
  displayMessage: DisplayMessage;
}

export enum AppNamesEnum {
  shopcart = 'shopcart'
}

