import { Component, inject } from '@angular/core';
import { LoginService } from '../../core/services/login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  standalone: true,
  template: `
    <nav class="bg-white border-b border-gray-200 px-4 py-2.5 fixed left-0 right-0 top-0 z-30 sm:ml-64">
      <div class="flex flex-wrap justify-between items-center">
        <div class="flex items-center">
           <!-- Placeholder for Breadcrumb or Page Title -->
           <h1 class="text-xl font-semibold text-gray-800">MKM Apps Manager</h1>
        </div>
        <div class="flex items-center gap-4">
          @if (loginService.userInfo()) {
            <div class="flex items-center gap-2">
              <div class="text-sm text-right hidden md:block">
                <div class="font-medium text-gray-900">Logged in as</div>
                <div class="text-gray-500">{{ loginService.userInfo()?.email }}</div>
              </div>
              <button type="button" class="flex text-sm bg-gray-800 rounded-full focus:ring-4 focus:ring-gray-300" aria-expanded="false" data-dropdown-toggle="dropdown-user">
                <span class="sr-only">Open user menu</span>
                <div class="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center text-white font-bold">
                  {{ getUserInitials() }}
                </div>
              </button>
            </div>
            <button (click)="logout()" class="text-sm text-red-600 hover:text-red-800 font-medium">Logout</button>
          }
        </div>
      </div>
    </nav>
  `
})
export class HeaderComponent {
  loginService = inject(LoginService);

  logout() {
    this.loginService.logout();
  }

  getUserInitials(): string {
    const email = this.loginService.userInfo()?.email || '';
    return email.substring(0, 2).toUpperCase();
  }
}

