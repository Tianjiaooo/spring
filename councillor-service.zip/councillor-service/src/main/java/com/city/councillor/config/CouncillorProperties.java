package com.city.councillor.config;

import com.city.councillor.model.Councillor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * Configuration properties for councillor data.
 * Binds councillor information from application.yml to Java objects.
 * Thread-safe for read operations in high-concurrency scenarios.
 */
@Component
@ConfigurationProperties(prefix = "councillors")
public class CouncillorProperties {

    /**
     * Map of ward number to councillor information.
     * Key: Ward number (Integer)
     * Value: Councillor object containing all councillor details
     */
    private Map<Integer, Councillor> wards = new HashMap<>();

    public Map<Integer, Councillor> getWards() {
        return wards;
    }

    public void setWards(Map<Integer, Councillor> wards) {
        this.wards = wards;
    }

    /**
     * Post-construct method to set ward numbers in councillor objects.
     * This ensures data consistency between map keys and councillor ward numbers.
     */
    public void postConstruct() {
        wards.forEach((wardNumber, councillor) -> {
            if (councillor.getWardNumber() == null) {
                councillor.setWardNumber(wardNumber);
            }
        });
    }
}

