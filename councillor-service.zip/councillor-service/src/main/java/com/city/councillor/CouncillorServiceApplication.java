package com.city.councillor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main application class for the Councillor Information Service.
 * 
 * This microservice provides RESTful APIs to query councillor information by ward number.
 * 
 * Key Features:
 * - Configuration-based data storage (YAML)
 * - Comprehensive API documentation via Swagger/OpenAPI
 * - Global exception handling with custom error responses
 * - Thread-safe immutable data structures
 * 
 * Architecture:
 * - Controller Layer: REST endpoints and request handling
 * - Service Layer: Business logic
 * - Configuration Layer: YAML-based data storage
 * 
 * Performance Optimizations:
 * - Data loaded once at startup for fast access
 * - Immutable data structures for thread safety
 * - Optimized Tomcat thread pool configuration
 * - Response compression enabled
 * - Stateless design for horizontal scalability
 * 
 * @author City Council IT Department
 * @version 1.0.0
 */
@SpringBootApplication
public class CouncillorServiceApplication {

    /**
     * Application entry point.
     * Starts the Spring Boot application with embedded Tomcat server.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        SpringApplication.run(CouncillorServiceApplication.class, args);
    }
}

