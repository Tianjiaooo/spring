package com.city.councillor.dto;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalDateTime;

/**
 * Standard error response structure for API error handling.
 * Provides consistent error information across all endpoints.
 */
public class ErrorResponse {

    /**
     * HTTP status code
     */
    private int status;

    /**
     * Error message describing what went wrong
     */
    private String message;

    /**
     * Detailed error description (optional)
     */
    private String details;

    /**
     * Timestamp when the error occurred
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime timestamp;

    /**
     * Request path where the error occurred
     */
    private String path;

    public ErrorResponse() {
    }

    public ErrorResponse(int status, String message, String details, LocalDateTime timestamp, String path) {
        this.status = status;
        this.message = message;
        this.details = details;
        this.timestamp = timestamp;
        this.path = path;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
}

