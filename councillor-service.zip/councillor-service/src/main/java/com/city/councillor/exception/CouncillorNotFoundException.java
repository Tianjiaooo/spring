package com.city.councillor.exception;

/**
 * Custom exception thrown when a councillor is not found for a given ward number.
 * This exception is handled by the global exception handler to return appropriate error responses.
 */
public class CouncillorNotFoundException extends RuntimeException {

    /**
     * Constructs a new CouncillorNotFoundException with the specified ward number.
     *
     * @param wardNumber the ward number that was not found
     */
    public CouncillorNotFoundException(Integer wardNumber) {
        super(String.format("Councillor not found for ward number: %d", wardNumber));
    }

    /**
     * Constructs a new CouncillorNotFoundException with a custom message.
     *
     * @param message the detail message
     */
    public CouncillorNotFoundException(String message) {
        super(message);
    }
}

