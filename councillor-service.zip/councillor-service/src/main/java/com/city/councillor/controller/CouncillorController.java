package com.city.councillor.controller;

import com.city.councillor.dto.ApiResponse;
import com.city.councillor.dto.ErrorResponse;
import com.city.councillor.exception.CouncillorNotFoundException;
import com.city.councillor.model.Councillor;
import com.city.councillor.service.CouncillorService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST Controller for councillor operations.
 * Provides endpoints to query councillor information by ward number.
 * 
 * High-Concurrency Considerations:
 * 1. Stateless design - no instance variables, thread-safe by design
 * 2. Read-only operations - no data modification, eliminates write contention
 * 3. In-memory data access - fast O(1) HashMap lookups with no I/O overhead
 * 4. Efficient response serialization - Jackson handles concurrent serialization
 */
@RestController
@RequestMapping("/api/councillors")
@Tag(name = "Councillor API", description = "Endpoints for querying councillor information by ward number")
public class CouncillorController {

    private static final Logger log = LoggerFactory.getLogger(CouncillorController.class);

    private final CouncillorService councillorService;

    public CouncillorController(CouncillorService councillorService) {
        this.councillorService = councillorService;
    }

    /**
     * Retrieves a councillor by ward number.
     * 
     * This endpoint is optimized for high concurrency:
     * - O(1) lookup time with HashMap
     * - Immutable data structures
     * - No synchronization overhead
     *
     * @param wardNumber the ward number to search for
     * @return ResponseEntity containing the councillor information
     * @throws CouncillorNotFoundException if no councillor found for the ward number
     */
    @Operation(
            summary = "Get councillor by ward number",
            description = """
                    Retrieves detailed information about a councillor for a specific ward number.
                    
                    **Features:**
                    - Returns complete councillor information for valid ward number
                    - Includes name, email, phone, office address, photo URL and additional info
                    - Optimized for high-concurrency with fast in-memory access
                    
                    **Example:**
                    ```
                    GET /api/councillors/1
                    ```
                    
                    **Notes:**
                    - Ward number must be a positive integer (greater than 0)
                    - Returns 404 error if ward number does not exist
                    - Returns 400 error if ward number is invalid (non-positive)
                    """
    )
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(
                    responseCode = "200",
                    description = "Successfully retrieved councillor information",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ApiResponse.class)
                    )
            ),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(
                    responseCode = "404",
                    description = "Councillor not found for the given ward number",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ErrorResponse.class)
                    )
            ),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(
                    responseCode = "400",
                    description = "Invalid ward number format (must be an integer)",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ErrorResponse.class)
                    )
            )
    })
    @GetMapping("/{wardNumber}")
    public ResponseEntity<ApiResponse<Councillor>> getCouncillorByWardNumber(
            @Parameter(
                    description = "Ward number (positive integer)",
                    required = true,
                    example = "1",
                    schema = @Schema(type = "integer", minimum = "1")
            )
            @PathVariable Integer wardNumber) {
        
        log.debug("Received request to get councillor for ward number: {}", wardNumber);
        
        // Validate ward number is positive
        if (wardNumber == null || wardNumber <= 0) {
            throw new IllegalArgumentException(
                "Ward number must be a positive integer, received: " + wardNumber);
        }
        
        // Retrieve councillor from service
        Councillor councillor = councillorService.getCouncillorByWardNumber(wardNumber)
                .orElseThrow(() -> new CouncillorNotFoundException(wardNumber));
        
        log.debug("Successfully retrieved councillor: {} for ward number: {}", 
                councillor.getName(), wardNumber);
        
        return ResponseEntity.ok(ApiResponse.success(councillor));
    }

    /**
     * Retrieves all councillors.
     * 
     * Returns a complete list of all configured councillors.
     * Data is loaded once at startup and kept in memory for fast access.
     *
     * @return ResponseEntity containing list of all councillors
     */
    @Operation(
            summary = "Get all councillors",
            description = """
                    Retrieves a complete list of all councillors across all wards.
                    
                    **Features:**
                    - Returns all councillor information configured in the system
                    - Includes ward number, name, contact details, photo URL for each councillor
                    - Fast in-memory access with O(1) retrieval performance
                    
                    **Use Cases:**
                    - Display councillor directory
                    - Bulk data export
                    - System administration and monitoring
                    
                    **Example:**
                    ```
                    GET /api/councillors
                    ```
                    """
    )
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(
                    responseCode = "200",
                    description = "Successfully retrieved all councillors",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ApiResponse.class)
                    )
            )
    })
    @GetMapping
    public ResponseEntity<ApiResponse<List<Councillor>>> getAllCouncillors() {
        
        log.debug("Received request to get all councillors");
        
        // Retrieve all councillors from service (immutable list)
        List<Councillor> councillors = councillorService.getAllCouncillors();
        
        log.debug("Successfully retrieved {} councillors", councillors.size());
        
        return ResponseEntity.ok(
                ApiResponse.success(
                        String.format("Retrieved %d councillors", councillors.size()),
                        councillors
                )
        );
    }
}

