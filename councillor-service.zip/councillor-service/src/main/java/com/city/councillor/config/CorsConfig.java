package com.city.councillor.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

import java.util.Arrays;
import java.util.Collections;

/**
 * CORS (Cross-Origin Resource Sharing) configuration.
 * 
 * Allows frontend applications hosted on different domains/ports to access this API.
 * This is essential for modern web applications with separate frontend and backend deployments.
 * 
 * Security Note:
 * - In development: Allows all origins for convenience
 * - In production: Should restrict to specific frontend domains
 */
@Configuration
public class CorsConfig {

    /**
     * Configures CORS filter with appropriate settings.
     * 
     * Development Configuration:
     * - Allows all origins (*)
     * - Allows common HTTP methods (GET, POST, PUT, DELETE, OPTIONS)
     * - Allows all headers
     * - Allows credentials (cookies, authorization headers)
     * 
     * Production Recommendations:
     * - Replace "*" with specific frontend domains
     * - Example: http://localhost:3000, https://city.gov
     * - Adjust max age based on caching requirements
     *
     * @return CorsFilter configured for cross-origin requests
     */
    @Bean
    public CorsFilter corsFilter() {
        CorsConfiguration config = new CorsConfiguration();
        
        // Allow credentials (cookies, authorization headers)
        config.setAllowCredentials(true);
        
        // Allowed origins - UPDATE THIS IN PRODUCTION
        // Development: Allow all origins
        config.setAllowedOriginPatterns(Collections.singletonList("*"));
        
        // Production example (uncomment and modify):
        // config.setAllowedOrigins(Arrays.asList(
        //     "http://localhost:3000",           // Local frontend development
        //     "https://city.gov",                // Production frontend
        //     "https://www.city.gov"             // Production frontend with www
        // ));
        
        // Allowed HTTP methods
        config.setAllowedMethods(Arrays.asList(
            "GET",
            "POST",
            "PUT",
            "DELETE",
            "OPTIONS",
            "PATCH"
        ));
        
        // Allowed headers
        config.setAllowedHeaders(Arrays.asList(
            "Origin",
            "Content-Type",
            "Accept",
            "Authorization",
            "X-Requested-With",
            "Access-Control-Request-Method",
            "Access-Control-Request-Headers"
        ));
        
        // Exposed headers (headers that frontend can access)
        config.setExposedHeaders(Arrays.asList(
            "Access-Control-Allow-Origin",
            "Access-Control-Allow-Credentials",
            "Content-Type"
        ));
        
        // How long the results of a preflight request can be cached (in seconds)
        // 3600 seconds = 1 hour
        config.setMaxAge(3600L);
        
        // Apply CORS configuration to all endpoints
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        
        return new CorsFilter(source);
    }
}


