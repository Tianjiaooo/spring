package com.city.councillor.service.impl;

import com.city.councillor.config.CouncillorProperties;
import com.city.councillor.model.Councillor;
import com.city.councillor.service.CouncillorService;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

/**
 * Implementation of CouncillorService.
 * 
 * Thread-Safety Design:
 * 1. Immutable data structures - thread-safe by design
 * 2. Unmodifiable collections - prevents concurrent modification
 * 3. Stateless service - no shared mutable state
 * 4. Data loaded once at startup from configuration file
 */
@Service
public class CouncillorServiceImpl implements CouncillorService {

    private static final Logger log = LoggerFactory.getLogger(CouncillorServiceImpl.class);

    private final CouncillorProperties councillorProperties;

    public CouncillorServiceImpl(CouncillorProperties councillorProperties) {
        this.councillorProperties = councillorProperties;
    }

    /**
     * Immutable list of all councillors for thread-safe access.
     * Initialized once at startup and never modified.
     */
    private List<Councillor> allCouncillors;

    /**
     * Post-construct initialization method.
     * Prepares immutable data structures for high-concurrency access.
     * This runs once when the service is created, ensuring thread safety.
     */
    @PostConstruct
    public void init() {
        // Initialize ward numbers in councillor objects
        councillorProperties.postConstruct();
        
        // Create an immutable list of all councillors
        allCouncillors = Collections.unmodifiableList(
            new ArrayList<>(councillorProperties.getWards().values())
        );
        
        log.info("Councillor service initialized with {} councillors", allCouncillors.size());
        
        // Log all ward numbers for debugging
        councillorProperties.getWards().keySet().forEach(
            wardNumber -> log.debug("Loaded councillor for ward number: {}", wardNumber)
        );
    }

    /**
     * {@inheritDoc}
     * 
     * Direct HashMap lookup for fast retrieval.
     * 
     * Time Complexity: O(1) - HashMap lookup
     * Thread Safety: Immutable data structure
     */
    @Override
    public Optional<Councillor> getCouncillorByWardNumber(Integer wardNumber) {
        log.debug("Fetching councillor for ward number: {}", wardNumber);
        
        // Direct HashMap lookup - O(1) complexity
        Councillor councillor = councillorProperties.getWards().get(wardNumber);
        
        if (councillor != null) {
            log.debug("Found councillor: {} for ward number: {}", councillor.getName(), wardNumber);
            return Optional.of(councillor);
        } else {
            log.debug("No councillor found for ward number: {}", wardNumber);
            return Optional.empty();
        }
    }

    /**
     * {@inheritDoc}
     * 
     * Returns an immutable list of all councillors.
     * The list is created once at startup and reused for all requests.
     * 
     * Thread Safety: Unmodifiable list ensures no concurrent modification issues
     */
    @Override
    public List<Councillor> getAllCouncillors() {
        log.debug("Fetching all councillors, total count: {}", allCouncillors.size());
        
        // Return the pre-constructed immutable list
        // No need to create a new list on each call - memory efficient
        return allCouncillors;
    }

    /**
     * {@inheritDoc}
     * 
     * Fast existence check using HashMap's containsKey method.
     * Time Complexity: O(1)
     */
    @Override
    public boolean wardExists(Integer wardNumber) {
        return councillorProperties.getWards().containsKey(wardNumber);
    }
}

