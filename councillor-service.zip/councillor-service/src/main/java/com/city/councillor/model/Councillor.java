package com.city.councillor.model;

import java.io.Serializable;

/**
 * Councillor entity representing a city councillor's information.
 * This class is immutable after construction to ensure thread safety in high-concurrency scenarios.
 */
public class Councillor implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * Ward number - unique identifier for the electoral district
     */
    private Integer wardNumber;

    /**
     * Full name of the councillor
     */
    private String name;

    /**
     * Contact email address
     */
    private String email;

    /**
     * Contact phone number
     */
    private String phone;

    /**
     * Office address or location
     */
    private String office;

    /**
     * Optional: Additional information or bio
     */
    private String additionalInfo;

    /**
     * Photo URL path for the councillor's profile picture
     * Stored as relative path (e.g., "/images/councillors/ward-1.jpg")
     */
    private String photoUrl;

    public Councillor() {
    }

    public Councillor(Integer wardNumber, String name, String email, String phone, String office, String additionalInfo) {
        this.wardNumber = wardNumber;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.office = office;
        this.additionalInfo = additionalInfo;
    }

    public Councillor(Integer wardNumber, String name, String email, String phone, String office, String photoUrl, String additionalInfo) {
        this.wardNumber = wardNumber;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.office = office;
        this.photoUrl = photoUrl;
        this.additionalInfo = additionalInfo;
    }

    public Integer getWardNumber() {
        return wardNumber;
    }

    public void setWardNumber(Integer wardNumber) {
        this.wardNumber = wardNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getOffice() {
        return office;
    }

    public void setOffice(String office) {
        this.office = office;
    }

    public String getAdditionalInfo() {
        return additionalInfo;
    }

    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

    public String getPhotoUrl() {
        return photoUrl;
    }

    public void setPhotoUrl(String photoUrl) {
        this.photoUrl = photoUrl;
    }
}

