# Councillor Photos Directory

## 📸 Purpose
This directory contains profile photos for city councillors.

## 📁 File Naming Convention
Photos should be named according to the ward number:
- `ward-1.jpg` - Photo for Ward 1 councillor
- `ward-2.jpg` - Photo for Ward 2 councillor
- `ward-3.jpg` - Photo for Ward 3 councillor
- ... and so on

## 📏 Photo Requirements
- **Format**: JPG (recommended) or PNG
- **Size**: Approximately 4KB per photo (or as small as possible)
- **Dimensions**: Recommended 300x400 pixels (portrait orientation)
- **File Name Pattern**: `ward-{number}.jpg` (e.g., ward-1.jpg, ward-2.jpg)

## 🔗 How It Works
When the application starts:
1. Photos are loaded from this directory as static resources
2. The `photoUrl` field in `application.yml` points to these files
3. Spring Boot automatically serves these files at `/images/councillors/ward-X.jpg`

## 🌐 Access URLs
After deployment, photos can be accessed via:
```
GET {base-url}/images/councillors/ward-1.jpg
GET {base-url}/images/councillors/ward-2.jpg
...
```

Examples:
- Development: `http://localhost:8080/images/councillors/ward-1.jpg`
- Production: `https://api.city.gov/councillor-service/images/councillors/ward-1.jpg`

## 📝 Adding New Photos
1. Place the photo file in this directory
2. Name it according to the convention: `ward-{number}.jpg`
3. Update the corresponding councillor entry in `application.yml`:
   ```yaml
   councillors:
     wards:
       6:
         name: "New Councillor"
         photoUrl: "/images/councillors/ward-6.jpg"
   ```
4. Rebuild and redeploy the application

## ⚠️ Important Notes
- Photos are packaged into the JAR file during build
- To update photos in production, you need to rebuild and redeploy
- Keep photos optimized for web (small file size, reasonable dimensions)
- All 8 councillor photos should total around 32KB or less


