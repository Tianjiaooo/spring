# Councillor Information Service

A high-performance Spring Boot microservice for querying city councillor information by ward number.

## Overview

This microservice provides RESTful APIs to retrieve councillor contact information and details based on ward numbers. The service is designed with high-concurrency scenarios in mind, utilizing thread-safe data structures and efficient in-memory access.

## Features

- ✅ **Query by Ward Number**: Retrieve specific councillor information using ward number
- ✅ **List All Councillors**: Get a complete list of all councillors
- ✅ **Councillor Photos**: Profile photos served as static resources (no external storage needed)
- ✅ **High-Concurrency Optimized**: Thread-safe immutable data structures with fast in-memory access
- ✅ **Configuration-Based Data**: Easy-to-update YAML configuration (no database required)
- ✅ **API Documentation**: Interactive Swagger UI for API exploration
- ✅ **Global Exception Handling**: Consistent error responses across all endpoints
- ✅ **Production-Ready**: Optimized Tomcat configuration and logging

## Technology Stack

- **Java 17**
- **Spring Boot 3.2.0**
- **SpringDoc OpenAPI 3** - API documentation (Swagger)
- **Maven** - Dependency management

## Project Structure

```
councillor-service/
├── src/
│   ├── main/
│   │   ├── java/com/city/councillor/
│   │   │   ├── config/              # Configuration classes
│   │   │   │   ├── CouncillorProperties.java
│   │   │   │   ├── CorsConfig.java
│   │   │   │   └── OpenApiConfig.java
│   │   │   ├── controller/          # REST controllers
│   │   │   │   └── CouncillorController.java
│   │   │   ├── dto/                 # Data transfer objects
│   │   │   │   ├── ApiResponse.java
│   │   │   │   └── ErrorResponse.java
│   │   │   ├── exception/           # Exception handling
│   │   │   │   ├── CouncillorNotFoundException.java
│   │   │   │   └── GlobalExceptionHandler.java
│   │   │   ├── model/               # Domain models
│   │   │   │   └── Councillor.java
│   │   │   ├── service/             # Business logic
│   │   │   │   ├── CouncillorService.java
│   │   │   │   └── impl/
│   │   │   │       └── CouncillorServiceImpl.java
│   │   │   └── CouncillorServiceApplication.java
│   │   └── resources/
│   │       ├── static/
│   │       │   └── images/
│   │       │       └── councillors/      # Councillor profile photos
│   │       ├── application.yml           # Main configuration
│   │       └── application-prod.yml      # Production configuration
│   └── test/                        # Unit and integration tests
├── pom.xml                          # Maven dependencies
└── README.md
```

## Quick Start

### Prerequisites

- Java 17 or higher
- Maven 3.6+

### Build the Project

```bash
mvn clean install
```

### Run the Application

**Development mode:**
```bash
mvn spring-boot:run
```

**Run JAR directly:**
```bash
java -jar target/councillor-service-1.0.0.jar
```

**Production mode:**
```bash
java -jar target/councillor-service-1.0.0.jar --spring.profiles.active=prod
```

The service will start on `http://localhost:8080`

## API Endpoints

### 1. Get Councillor by Ward Number

**Endpoint**: `GET /api/councillors/{wardNumber}`

**Description**: Retrieves councillor information for a specific ward number.

**Example Request**:
```bash
curl http://localhost:8080/api/councillors/1
```

**Success Response**:
```json
{
  "success": true,
  "message": "Request processed successfully",
  "data": {
    "wardNumber": 1,
    "name": "John Smith",
    "email": "john.smith@city.gov",
    "phone": "+1-416-555-0101",
    "office": "City Hall, Room 201",
    "photoUrl": "/images/councillors/ward-1.jpg",
    "additionalInfo": "Specializes in urban development and infrastructure"
  }
}
```

**Error Response** (Ward Not Found):
```json
{
  "status": 404,
  "message": "Councillor Not Found",
  "details": "Councillor not found for ward number: 99",
  "timestamp": "2024-11-21 10:30:45",
  "path": "/api/councillors/99"
}
```

### 2. Get All Councillors

**Endpoint**: `GET /api/councillors`

**Description**: Retrieves a list of all councillors.

**Example Request**:
```bash
curl http://localhost:8080/api/councillors
```

**Success Response**:
```json
{
  "success": true,
  "message": "Retrieved 5 councillors",
  "data": [
    {
      "wardNumber": 1,
      "name": "John Smith",
      "email": "john.smith@city.gov",
      "phone": "+1-416-555-0101",
      "office": "City Hall, Room 201",
      "photoUrl": "/images/councillors/ward-1.jpg",
      "additionalInfo": "Specializes in urban development and infrastructure"
    },
    {
      "wardNumber": 2,
      "name": "Jane Doe",
      "email": "jane.doe@city.gov",
      "phone": "+1-416-555-0102",
      "office": "City Hall, Room 202",
      "photoUrl": "/images/councillors/ward-2.jpg",
      "additionalInfo": "Focus on environmental and sustainability initiatives"
    }
    // ... more councillors
  ]
}
```

## API Documentation

Interactive API documentation is available via Swagger UI:

**URL**: `http://localhost:8080/swagger-ui.html`

Features:
- Complete API specification
- Interactive request testing
- Request/response examples
- Schema definitions
- Online debugging

## Configuration

### Updating Councillor Information

Councillor data is stored in `src/main/resources/application.yml`. To update or add councillors:

1. Open `application.yml`
2. Navigate to the `councillors.wards` section
3. Add or modify ward entries:

```yaml
councillors:
  wards:
    6:
      name: "New Councillor Name"
      email: "new.councillor@city.gov"
      phone: "+1-416-555-0106"
      office: "City Hall, Room 206"
      photoUrl: "/images/councillors/ward-6.jpg"
      additionalInfo: "Additional information"
```

4. Restart the service for changes to take effect

### Managing Councillor Photos

Councillor profile photos are stored as static resources within the application, eliminating the need for external file storage or databases.

**Photo Location**: `src/main/resources/static/images/councillors/`

**Adding or Updating Photos**:

1. Place the photo file in the councillors directory
2. Follow the naming convention: `ward-{number}.jpg` (e.g., `ward-1.jpg`, `ward-2.jpg`)
3. Update the corresponding entry in `application.yml`:

```yaml
councillors:
  wards:
    1:
      name: "John Smith"
      photoUrl: "/images/councillors/ward-1.jpg"  # Add this line
```

4. Rebuild and redeploy the application:

```bash
mvn clean package
java -jar target/councillor-service-1.0.0.jar
```

**Photo Requirements**:
- **Format**: JPG (recommended) or PNG
- **Size**: Keep files small (approximately 4KB per photo recommended)
- **Dimensions**: Recommended 300x400 pixels (portrait orientation)
- **Total Size**: All photos (~8 photos) should be around 32KB or less

**Accessing Photos**:

Photos are automatically served as static resources:

```bash
# Direct photo access
GET http://localhost:8080/images/councillors/ward-1.jpg

# Photos are also included in API responses
GET http://localhost:8080/api/councillors/1
# Response includes: "photoUrl": "/images/councillors/ward-1.jpg"
```

**Deployment Considerations**:
- Photos are packaged into the JAR file during build
- Works seamlessly across different deployment environments (relative path automatically adapts)
- No need for external CDN or file storage for small photo collections
- To update photos in production, rebuild and redeploy the JAR

### Performance Tuning

High-concurrency settings can be adjusted in `application.yml`:

```yaml
server:
  tomcat:
    threads:
      max: 200              # Maximum worker threads
      min-spare: 10         # Minimum spare threads
    max-connections: 10000  # Maximum concurrent connections
```

## High-Concurrency Design

This service is optimized for high-concurrency scenarios:

### 1. **In-Memory Data Access**
- Data loaded once at startup into memory HashMap
- O(1) lookup time complexity
- Direct memory access without I/O overhead
- Thread-safe with immutable data structures

### 2. **Immutable Data Structures**
- Thread-safe by design
- No synchronization overhead
- Prevents concurrent modification issues

### 3. **Stateless Service**
- No shared mutable state
- Horizontally scalable
- Each request is independent

### 4. **Optimized Thread Pool**
- Configurable Tomcat worker threads
- Connection pooling
- Efficient resource utilization

### 5. **Response Compression**
- Reduces network bandwidth
- Faster response times
- Enabled for JSON responses

## Testing

### Manual Testing with cURL

```bash
# Test valid ward number
curl http://localhost:8080/api/councillors/1

# Test invalid ward number (should return 404)
curl http://localhost:8080/api/councillors/999

# Test get all councillors
curl http://localhost:8080/api/councillors
```

### Load Testing

For high-concurrency testing, use tools like Apache JMeter or Gatling:

```bash
# Example with Apache Bench (ab)
ab -n 10000 -c 100 http://localhost:8080/api/councillors/1
```

This simulates 10,000 requests with 100 concurrent connections.

## Monitoring

### Application Logs

Logs are configured in `application.yml`:

```yaml
logging:
  level:
    com.city.councillor: DEBUG           # Application logs
```

## Deployment

### Docker Deployment (Optional)

Create a `Dockerfile`:

```dockerfile
FROM openjdk:17-jdk-slim
WORKDIR /app
COPY target/councillor-service-1.0.0.jar app.jar
EXPOSE 8080
ENTRYPOINT ["java", "-jar", "app.jar"]
```

Build and run:

```bash
docker build -t councillor-service .
docker run -p 8080:8080 councillor-service
```

### Production Deployment

1. Build the production JAR:
```bash
mvn clean package -DskipTests
```

2. Run with production profile:
```bash
java -jar target/councillor-service-1.0.0.jar --spring.profiles.active=prod
```

3. Configure reverse proxy (Nginx/Apache) for load balancing
4. Set up monitoring and alerting
5. Configure log aggregation (ELK stack, Splunk, etc.)

## Troubleshooting

### Issue: Service won't start

**Solution**: Check if port 8080 is already in use:
```bash
lsof -i :8080
```

Change port in `application.yml` if needed:
```yaml
server:
  port: 8081
```

### Issue: Councillor not found

**Solution**: Verify the ward number exists in `application.yml` under `councillors.wards`

## Key Technical Features

### Minimal Third-Party Dependencies
- ✅ Simple in-memory data access without external cache dependencies
- ✅ Standard Java code without Lombok
- ✅ No Actuator health checks
- ✅ Only SpringDoc OpenAPI retained for API documentation
- ✅ Complies with City system standards, reduced external dependencies

### CORS Configuration
- ✅ Cross-Origin Resource Sharing enabled for frontend integration
- ✅ Configured in `CorsConfig.java` for flexible deployment
- ✅ Development mode: Allows all origins for easy testing
- ✅ Production ready: Easy to restrict to specific frontend domains
- ✅ Supports credentials (cookies, authorization headers)

**Note:** For production deployment, update the allowed origins in `CorsConfig.java`:
```java
// Replace this:
config.setAllowedOriginPatterns(Collections.singletonList("*"));

// With your actual frontend domains:
config.setAllowedOrigins(Arrays.asList(
    "https://city.gov",
    "https://www.city.gov"
));
```

## Contact

City Council IT Department
- Email: it@city.gov

## Version History

- **1.0.0** (2024-11-21)
  - Initial release
  - Basic councillor query functionality
  - High-concurrency optimizations
  - Swagger documentation
  - Removed third-party dependencies (Caffeine, Lombok, Actuator)

