package com.city.councillor.config;

import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Cache configuration using Spring's built-in ConcurrentMap cache.
 * Optimized for high-concurrency read operations with minimal latency.
 * Uses Spring Framework's native cache implementation without third-party dependencies.
 */
@Configuration
@EnableCaching
public class CacheConfig {

    /**
     * Cache name for councillor data
     */
    public static final String COUNCILLOR_CACHE = "councillors";

    /**
     * Configures Spring's built-in ConcurrentMapCacheManager for high concurrency.
     * 
     * Cache Strategy:
     * - Uses ConcurrentHashMap for thread-safe caching
     * - No size limit (suitable for small datasets like ~20 councillors)
     * - No automatic expiration (data is static and loaded from configuration)
     * - Lightweight and efficient for read-heavy workloads
     * 
     * @return CacheManager configured with ConcurrentMap
     */
    @Bean
    public CacheManager cacheManager() {
        // Spring's built-in cache manager using ConcurrentHashMap
        // Thread-safe and optimized for high-concurrency scenarios
        return new ConcurrentMapCacheManager(COUNCILLOR_CACHE);
    }
}

