package com.city.councillor.service;

import com.city.councillor.model.Councillor;

import java.util.List;
import java.util.Optional;

/**
 * Service interface for councillor operations.
 * Defines the contract for councillor data access.
 */
public interface CouncillorService {

    /**
     * Retrieves a councillor by ward number.
     * This method is optimized for high-concurrency scenarios with caching.
     *
     * @param wardNumber the ward number to search for
     * @return Optional containing the councillor if found, empty otherwise
     */
    Optional<Councillor> getCouncillorByWardNumber(Integer wardNumber);

    /**
     * Retrieves all councillors.
     * Returns a complete list of all configured councillors.
     * This method is also cached for performance.
     *
     * @return List of all councillors
     */
    List<Councillor> getAllCouncillors();

    /**
     * Checks if a ward number exists in the configuration.
     *
     * @param wardNumber the ward number to check
     * @return true if the ward exists, false otherwise
     */
    boolean wardExists(Integer wardNumber);
}

