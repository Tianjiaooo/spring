package com.city.councillor.controller;

import com.city.councillor.dto.ApiResponse;
import com.city.councillor.dto.ErrorResponse;
import com.city.councillor.exception.CouncillorNotFoundException;
import com.city.councillor.model.Councillor;
import com.city.councillor.service.CouncillorService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST Controller for councillor operations.
 * Provides endpoints to query councillor information by ward number.
 * 
 * High-Concurrency Considerations:
 * 1. Stateless design - no instance variables, thread-safe by design
 * 2. Read-only operations - no data modification, eliminates write contention
 * 3. Cached service layer - reduces database/config access overhead
 * 4. Efficient response serialization - Jackson handles concurrent serialization
 */
@RestController
@RequestMapping("/api/councillors")
@Tag(name = "Councillor API", description = "Endpoints for querying councillor information by ward number")
public class CouncillorController {

    private static final Logger log = LoggerFactory.getLogger(CouncillorController.class);

    private final CouncillorService councillorService;

    public CouncillorController(CouncillorService councillorService) {
        this.councillorService = councillorService;
    }

    /**
     * Retrieves a councillor by ward number.
     * 
     * This endpoint is optimized for high concurrency:
     * - O(1) lookup time with caching
     * - Immutable data structures
     * - No synchronization overhead
     *
     * @param wardNumber the ward number to search for
     * @return ResponseEntity containing the councillor information
     * @throws CouncillorNotFoundException if no councillor found for the ward number
     */
    @Operation(
            summary = "Get councillor by ward number",
            description = """
                    Retrieves detailed information about a councillor for a specific ward number.
                    
                    **Features:**
                    - Returns complete councillor information for valid ward number
                    - Includes name, email, phone, office address and additional info
                    - Optimized for high-concurrency with fast response time
                    
                    **Example:**
                    ```
                    GET /api/councillors/1
                    ```
                    
                    **Notes:**
                    - Ward number must be a positive integer
                    - Returns 404 error if ward number does not exist
                    """
    )
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(
                    responseCode = "200",
                    description = "Successfully retrieved councillor information",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ApiResponse.class)
                    )
            ),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(
                    responseCode = "404",
                    description = "Councillor not found for the given ward number",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ErrorResponse.class)
                    )
            ),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(
                    responseCode = "400",
                    description = "Invalid ward number format (must be an integer)",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ErrorResponse.class)
                    )
            )
    })
    @GetMapping("/{wardNumber}")
    public ResponseEntity<ApiResponse<Councillor>> getCouncillorByWardNumber(
            @Parameter(
                    description = "Ward number (positive integer)",
                    required = true,
                    example = "1",
                    schema = @Schema(type = "integer", minimum = "1")
            )
            @PathVariable Integer wardNumber) {
        
        log.info("Received request to get councillor for ward number: {}", wardNumber);
        
        // Retrieve councillor from service (cached for performance)
        Councillor councillor = councillorService.getCouncillorByWardNumber(wardNumber)
                .orElseThrow(() -> new CouncillorNotFoundException(wardNumber));
        
        log.info("Successfully retrieved councillor: {} for ward number: {}", 
                councillor.getName(), wardNumber);
        
        return ResponseEntity.ok(ApiResponse.success(councillor));
    }

    /**
     * Retrieves all councillors.
     * 
     * Returns a complete list of all configured councillors.
     * This endpoint is also cached for optimal performance under high load.
     *
     * @return ResponseEntity containing list of all councillors
     */
    @Operation(
            summary = "Get all councillors",
            description = """
                    Retrieves a complete list of all councillors across all wards.
                    
                    **Features:**
                    - Returns all councillor information configured in the system
                    - Includes ward number, name, contact details for each councillor
                    - Data is cached for excellent query performance
                    
                    **Use Cases:**
                    - Display councillor directory
                    - Bulk data export
                    - System administration and monitoring
                    
                    **Example:**
                    ```
                    GET /api/councillors
                    ```
                    """
    )
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(
                    responseCode = "200",
                    description = "Successfully retrieved all councillors",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ApiResponse.class)
                    )
            )
    })
    @GetMapping
    public ResponseEntity<ApiResponse<List<Councillor>>> getAllCouncillors() {
        
        log.info("Received request to get all councillors");
        
        // Retrieve all councillors from service (cached and immutable)
        List<Councillor> councillors = councillorService.getAllCouncillors();
        
        log.info("Successfully retrieved {} councillors", councillors.size());
        
        return ResponseEntity.ok(
                ApiResponse.success(
                        String.format("Retrieved %d councillors", councillors.size()),
                        councillors
                )
        );
    }
}

