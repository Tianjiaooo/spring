package com.city.councillor.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.servers.Server;
import io.swagger.v3.oas.models.ExternalDocumentation;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

/**
 * OpenAPI (Swagger) configuration for API documentation.
 * Provides interactive API documentation at /swagger-ui.html
 * 
 * Access points:
 * - Swagger UI: http://localhost:8080/swagger-ui.html
 * - API Docs JSON: http://localhost:8080/api-docs
 */
@Configuration
public class OpenApiConfig {

    @Value("${server.port:8080}")
    private String serverPort;

    @Value("${spring.application.name:councillor-service}")
    private String applicationName;

    /**
     * Configures OpenAPI documentation with comprehensive API information.
     * Includes server configuration, contact information, and API metadata.
     *
     * @return OpenAPI configuration object
     */
    @Bean
    public OpenAPI councillorServiceOpenAPI() {
        // Local development server
        Server localServer = new Server();
        localServer.setUrl("http://localhost:" + serverPort);
        localServer.setDescription("Local Development Server");

        // Production server (can be configured)
        Server prodServer = new Server();
        prodServer.setUrl("https://api.city.gov/councillor");
        prodServer.setDescription("Production Server");

        // Contact information
        Contact contact = new Contact();
        contact.setName("City Council IT Department");
        contact.setEmail("it@city.gov");
        contact.setUrl("https://city.gov/it");

        // External documentation
        ExternalDocumentation externalDocs = new ExternalDocumentation();
        externalDocs.setDescription("City Council API Documentation");
        externalDocs.setUrl("https://docs.city.gov/api");

        // API information
        Info info = new Info()
                .title("Councillor Information Service API")
                .version("1.0.0")
                .description("""
                        ## Overview
                        RESTful API service for querying city councillor information by ward number.
                        
                        ## Key Features
                        - High-concurrency optimized with Spring ConcurrentMap cache
                        - Complete councillor information: name, email, phone, office address
                        - Flexible queries: search by ward number or get all councillors
                        - Unified error handling with standardized error responses
                        - Comprehensive API documentation with interactive Swagger UI
                        
                        ## Usage
                        1. Use `/api/councillors/{wardNumber}` to query councillor by ward number
                        2. Use `/api/councillors` to get all councillors
                        3. All responses use unified JSON format
                        
                        ## Technology Stack
                        - Spring Boot 3.2.0
                        - Java 17
                        - Spring Cache (ConcurrentMap)
                        """)
                .contact(contact);

        return new OpenAPI()
                .info(info)
                .servers(List.of(localServer, prodServer))
                .externalDocs(externalDocs);
    }
}

