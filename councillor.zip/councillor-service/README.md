# Councillor Information Service

A high-performance Spring Boot microservice for querying city councillor information by ward number.

## Overview

This microservice provides RESTful APIs to retrieve councillor contact information and details based on ward numbers. The service is designed with high-concurrency scenarios in mind, utilizing caching strategies and thread-safe data structures.

## Features

- ✅ **Query by Ward Number**: Retrieve specific councillor information using ward number
- ✅ **List All Councillors**: Get a complete list of all councillors
- ✅ **High-Concurrency Optimized**: Spring ConcurrentMap cache and immutable data structures
- ✅ **Configuration-Based Data**: Easy-to-update YAML configuration (no database required)
- ✅ **API Documentation**: Interactive Swagger UI for API exploration
- ✅ **Global Exception Handling**: Consistent error responses across all endpoints
- ✅ **Production-Ready**: Optimized Tomcat configuration and logging

## Technology Stack

- **Java 17**
- **Spring Boot 3.2.0**
- **Spring Cache (ConcurrentMap)** - High-performance local caching
- **SpringDoc OpenAPI 3** - API documentation (Swagger)
- **Maven** - Dependency management

## Project Structure

```
councillor-service/
├── src/
│   ├── main/
│   │   ├── java/com/city/councillor/
│   │   │   ├── config/              # Configuration classes
│   │   │   │   ├── CacheConfig.java
│   │   │   │   ├── CouncillorProperties.java
│   │   │   │   └── OpenApiConfig.java
│   │   │   ├── controller/          # REST controllers
│   │   │   │   └── CouncillorController.java
│   │   │   ├── dto/                 # Data transfer objects
│   │   │   │   ├── ApiResponse.java
│   │   │   │   └── ErrorResponse.java
│   │   │   ├── exception/           # Exception handling
│   │   │   │   ├── CouncillorNotFoundException.java
│   │   │   │   └── GlobalExceptionHandler.java
│   │   │   ├── model/               # Domain models
│   │   │   │   └── Councillor.java
│   │   │   ├── service/             # Business logic
│   │   │   │   ├── CouncillorService.java
│   │   │   │   └── impl/
│   │   │   │       └── CouncillorServiceImpl.java
│   │   │   └── CouncillorServiceApplication.java
│   │   └── resources/
│   │       ├── application.yml           # Main configuration
│   │       └── application-prod.yml      # Production configuration
│   └── test/                        # Unit and integration tests
├── pom.xml                          # Maven dependencies
└── README.md
```

## Quick Start

### Prerequisites

- Java 17 or higher
- Maven 3.6+

### Build the Project

```bash
mvn clean install
```

### Run the Application

**Development mode:**
```bash
mvn spring-boot:run
```

**Run JAR directly:**
```bash
java -jar target/councillor-service-1.0.0.jar
```

**Production mode:**
```bash
java -jar target/councillor-service-1.0.0.jar --spring.profiles.active=prod
```

The service will start on `http://localhost:8080`

## API Endpoints

### 1. Get Councillor by Ward Number

**Endpoint**: `GET /api/councillors/{wardNumber}`

**Description**: Retrieves councillor information for a specific ward number.

**Example Request**:
```bash
curl http://localhost:8080/api/councillors/1
```

**Success Response**:
```json
{
  "success": true,
  "message": "Request processed successfully",
  "data": {
    "wardNumber": 1,
    "name": "John Smith",
    "email": "john.smith@city.gov",
    "phone": "+1-416-555-0101",
    "office": "City Hall, Room 201",
    "additionalInfo": "Specializes in urban development and infrastructure"
  }
}
```

**Error Response** (Ward Not Found):
```json
{
  "status": 404,
  "message": "Councillor Not Found",
  "details": "Councillor not found for ward number: 99",
  "timestamp": "2024-11-21 10:30:45",
  "path": "/api/councillors/99"
}
```

### 2. Get All Councillors

**Endpoint**: `GET /api/councillors`

**Description**: Retrieves a list of all councillors.

**Example Request**:
```bash
curl http://localhost:8080/api/councillors
```

**Success Response**:
```json
{
  "success": true,
  "message": "Retrieved 5 councillors",
  "data": [
    {
      "wardNumber": 1,
      "name": "John Smith",
      "email": "john.smith@city.gov",
      "phone": "+1-416-555-0101",
      "office": "City Hall, Room 201",
      "additionalInfo": "Specializes in urban development and infrastructure"
    },
    {
      "wardNumber": 2,
      "name": "Jane Doe",
      "email": "jane.doe@city.gov",
      "phone": "+1-416-555-0102",
      "office": "City Hall, Room 202",
      "additionalInfo": "Focus on environmental and sustainability initiatives"
    }
    // ... more councillors
  ]
}
```

## API Documentation

Interactive API documentation is available via Swagger UI:

**URL**: `http://localhost:8080/swagger-ui.html`

Features:
- Complete API specification
- Interactive request testing
- Request/response examples
- Schema definitions
- Online debugging

## Configuration

### Updating Councillor Information

Councillor data is stored in `src/main/resources/application.yml`. To update or add councillors:

1. Open `application.yml`
2. Navigate to the `councillors.wards` section
3. Add or modify ward entries:

```yaml
councillors:
  wards:
    6:
      name: "New Councillor Name"
      email: "new.councillor@city.gov"
      phone: "+1-416-555-0106"
      office: "City Hall, Room 206"
      additionalInfo: "Additional information"
```

4. Restart the service for changes to take effect

### Performance Tuning

High-concurrency settings can be adjusted in `application.yml`:

```yaml
server:
  tomcat:
    threads:
      max: 200              # Maximum worker threads
      min-spare: 10         # Minimum spare threads
    max-connections: 10000  # Maximum concurrent connections
```

Cache configuration in `CacheConfig.java`:

```java
// Uses Spring ConcurrentMapCacheManager
// Based on ConcurrentHashMap implementation
// Thread-safe and suitable for high-concurrency scenarios
```

## High-Concurrency Design

This service is optimized for high-concurrency scenarios:

### 1. **Spring ConcurrentMap Cache**
- In-memory caching based on ConcurrentHashMap
- O(1) lookup time complexity
- Reduces configuration file access overhead
- Thread-safe concurrent access
- Native Spring support with no third-party dependencies

### 2. **Immutable Data Structures**
- Thread-safe by design
- No synchronization overhead
- Prevents concurrent modification issues

### 3. **Stateless Service**
- No shared mutable state
- Horizontally scalable
- Each request is independent

### 4. **Optimized Thread Pool**
- Configurable Tomcat worker threads
- Connection pooling
- Efficient resource utilization

### 5. **Response Compression**
- Reduces network bandwidth
- Faster response times
- Enabled for JSON responses

## Testing

### Manual Testing with cURL

```bash
# Test valid ward number
curl http://localhost:8080/api/councillors/1

# Test invalid ward number (should return 404)
curl http://localhost:8080/api/councillors/999

# Test get all councillors
curl http://localhost:8080/api/councillors
```

### Load Testing

For high-concurrency testing, use tools like Apache JMeter or Gatling:

```bash
# Example with Apache Bench (ab)
ab -n 10000 -c 100 http://localhost:8080/api/councillors/1
```

This simulates 10,000 requests with 100 concurrent connections.

## Monitoring

### Application Logs

Logs are configured in `application.yml`:

```yaml
logging:
  level:
    com.city.councillor: DEBUG           # Application logs
    org.springframework.cache: DEBUG     # Cache logs
```

### Cache Monitoring

Cache performance can be monitored through logs. Spring ConcurrentMap provides basic cache statistics.

## Deployment

### Docker Deployment (Optional)

Create a `Dockerfile`:

```dockerfile
FROM openjdk:17-jdk-slim
WORKDIR /app
COPY target/councillor-service-1.0.0.jar app.jar
EXPOSE 8080
ENTRYPOINT ["java", "-jar", "app.jar"]
```

Build and run:

```bash
docker build -t councillor-service .
docker run -p 8080:8080 councillor-service
```

### Production Deployment

1. Build the production JAR:
```bash
mvn clean package -DskipTests
```

2. Run with production profile:
```bash
java -jar target/councillor-service-1.0.0.jar --spring.profiles.active=prod
```

3. Configure reverse proxy (Nginx/Apache) for load balancing
4. Set up monitoring and alerting
5. Configure log aggregation (ELK stack, Splunk, etc.)

## Troubleshooting

### Issue: Service won't start

**Solution**: Check if port 8080 is already in use:
```bash
lsof -i :8080
```

Change port in `application.yml` if needed:
```yaml
server:
  port: 8081
```

### Issue: Councillor not found

**Solution**: Verify the ward number exists in `application.yml` under `councillors.wards`

### Issue: Cache not working

**Solution**: Ensure `@EnableCaching` is present in the main application class and check cache logs

## Key Technical Features

### Minimal Third-Party Dependencies
- ✅ Removed Caffeine cache, using Spring native ConcurrentMap
- ✅ Removed Lombok, using standard Java code
- ✅ Removed Actuator health checks
- ✅ Only SpringDoc OpenAPI retained for API documentation
- ✅ Complies with City system standards, reduced external dependencies

## Contact

City Council IT Department
- Email: it@city.gov

## Version History

- **1.0.0** (2024-11-21)
  - Initial release
  - Basic councillor query functionality
  - High-concurrency optimizations
  - Swagger documentation
  - Removed third-party dependencies (Caffeine, Lombok, Actuator)

